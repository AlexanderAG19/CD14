echo -e '\033]2;Skunkhash (HDAC) - bsod pool\007'
./CryptoDredge -a skunk -o stratum+tcp://eu.bsod.pw:2470 -u WALLET_ADDRESS -p c=HDAC
printf "Press <ENTER> to continue..."
read -r continueKey
