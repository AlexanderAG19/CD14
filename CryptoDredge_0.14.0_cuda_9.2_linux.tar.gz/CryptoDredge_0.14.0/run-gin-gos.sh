echo -e '\033]2;Lyra2Z (GIN) - Gos.cx\007'
./CryptoDredge -a lyra2z -o stratum+tcp://eu.gos.cx:4545 -u wallet.rigName -p c=GIN
printf "Press <ENTER> to continue..."
read -r continueKey