echo -e '\033]2;Lyra2REvc0ban (c0ban) - pecadol pool\007'
./CryptoDredge -a lyra2vc0ban -o stratum+tcp://pool.pecadol.xyz:4534 -u WALLET_ADDRESS -p c=RYO
printf "Press <ENTER> to continue..."
read -r continueKey
