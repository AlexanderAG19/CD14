echo -e '\033]2;X22I (SUQA) - beepool\007'
./CryptoDredge -a x22i -o stratum+tcp://suqa-pool.beepool.org:9504 -u WALLET_ADDRESS -p x
printf "Press <ENTER> to continue..."
read -r continueKey
